Created by WildLeoKnight
https://wildleoknight.itch.io

"An aseprite extension with the 32 Super Game Boy palettes"