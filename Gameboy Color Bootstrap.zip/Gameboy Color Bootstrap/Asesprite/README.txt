Created by WildLeoKnight
https://wildleoknight.itch.io

"An aseprite extension with the 145 Game Boy Bootstrap palettes"